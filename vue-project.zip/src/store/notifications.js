// src/store/notifications.js
import { defineStore } from 'pinia';


export const useNotificationsStore = defineStore({
    id: 'notifications',
    state: () => ({
        notifications: [],
        personList: [
            { id: 1, name: '王强', age: 33, position: '架构师', avatar: 'path/to/avatar1.jpg', editing: false },
            { id: 2, name: '张伟', age: 34, position: 'ai设计师', avatar: 'path/to/avatar2.jpg', editing: false },
            { id: 3, name: '王李', age: 35, position: '公司法人', avatar: 'path/to/avatar3.jpg', editing: false },
            { id: 4, name: '赵高', age: 36, position: '数据分析师', avatar: 'path/to/avatar4.jpg', editing: false },
            { id: 5, name: '嬴政', age: 37, position: '数据分析师', avatar: 'path/to/avatar5.jpg', editing: false },
            { id: 6, name: '华佗', age: 38, position: '数据分析师', avatar: 'path/to/avatar6.jpg', editing: false },
            { id: 7, name: '刘备', age: 39, position: '后端开发工程师', avatar: 'path/to/avatar7.jpg', editing: false },
            { id: 8, name: '关羽', age: 40, position: '产品经理', avatar: 'path/to/avatar8.jpg', editing: false },
            { id: 9, name: '张飞', age: 20, position: '后端开发工程师', avatar: 'path/to/avatar9.jpg', editing: false },
            { id: 10, name: '赵云', age: 21, position: '后端开发工程师', avatar: 'path/to/avatar10.jpg', editing: false },
            { id: 11, name: '孙权', age: 22, position: '数据科学家', avatar: 'path/to/avatar11.jpg', editing: false },
            { id: 12, name: '曹操', age: 23, position: 'UI/UX设计师', avatar: 'path/to/avatar12.jpg', editing: false },
            { id: 13, name: '小乔', age: 24, position: '安全工程师', avatar: 'path/to/avatar13.jpg', editing: false },
            { id: 14, name: '大桥', age: 25, position: '项目经理', avatar: 'path/to/avatar14.jpg', editing: false },
            { id: 15, name: '力扬', age: 26, position: '软件工程师', avatar: 'path/to/avatar15.jpg', editing: false }
        ]
    }),



    actions: {
        addNotification(notification) {
            this.notifications.push(notification);
        },
        addPerson(person) {
            // 确保没有重复添加
            if (!this.personList.some(p => p.id === person.id)) {
                this.personList.push(person);
                this.addNotification({
                    type: 'success',
                    message: `已成功添加 ${person.name}`,
                    date: new Date().toISOString().split('T')[0]
                });
            } else {
            }
        },
        deletePerson(id) {
            const person = this.personList.find(p => p.id === id);
            if (person) {
                const index = this.personList.findIndex(p => p.id === id);
                if (index !== -1) {
                    this.personList.splice(index, 1);
                    this.addNotification({
                        type: 'success',
                        message: `已成功删除 ${person.name}`,
                        date: new Date().toISOString().split('T')[0]
                    });
                }
            }
        },
        updatePerson(updatedPerson) {
            this.personList = this.personList.map(person =>
                person.id === updatedPerson.id ? updatedPerson : person
            );
            // 添加更新操作时的通知
            this.addNotification({
                type: 'success',
                message: `已成功更新 ${updatedPerson.name}`,
                date: new Date().toISOString().split('T')[0]
            });
        }
    },
    persist: true,
});