<template>
  <el-container class="layout-container">
    <!-- 侧边栏，根据是否折叠调整宽度 -->
    <el-aside :width="isCollapse ? '64px' : '240px'" class="aside">
      <div class="logo">
        <h1 v-show="!isCollapse">人员管理系统</h1>
        <h1 v-show="isCollapse">系统</h1>
      </div>
      <!-- 侧边栏菜单 -->
      <el-menu
        class="el-menu-vertical"
        background-color="#7367f0"
        text-color="#fff"
        active-text-color="#fff"
        :default-active="$route.path"
        router
        :collapse="isCollapse"
      >
        <el-menu-item index="/home">
          <el-icon><HomeFilled /></el-icon>
          <span>首页</span>
        </el-menu-item>
        <el-menu-item index="/person-list">
          <el-icon><User /></el-icon>
          <span>人员列表</span>
        </el-menu-item>
        <el-menu-item index="/notifications">
          <el-icon><Bell /></el-icon>
          <span>通知</span>
        </el-menu-item>
      </el-menu>
    </el-aside>

    <el-container>
      <!-- 头部 -->
      <el-header class="header">
        <div class="header-left">
          <el-icon class="fold-btn" @click="toggleCollapse">
            <component :is="isCollapse ? 'Expand' : 'Fold'" />
          </el-icon>
          <!-- 添加面包屑 -->
          <el-breadcrumb separator="/">
            <el-breadcrumb-item
              v-if="currentRoute !== '首页'"
              :to="{ path: '/home' }"
              >首页
            </el-breadcrumb-item>
            <el-breadcrumb-item>{{ currentRoute }}</el-breadcrumb-item>
          </el-breadcrumb>
        </div>

        <div class="user-info">
          <el-dropdown @command="handleCommand">
            <span class="avatar-container">
              <img src="../assets/p1.jpg" class="avatar" />
              <span class="username">{{ username }}</span>
              <el-icon class="el-icon--right"><arrow-down /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="logout">退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </el-header>

      <!-- 主要内容区域 -->
      <el-main class="main">
        <router-view v-slot="{ Component }">
          <!-- transition 路由切换动画 -->
          <transition name="fade" mode="out-in">
            <component :is="Component" @new-person-added="addNewPerson" />
          </transition>
        </router-view>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
import {
  HomeFilled,
  User,
  Bell,
  Search,
  ArrowDown,
  Expand,
  Fold,
} from "@element-plus/icons-vue"
import { useNotificationsStore } from "../store/notifications"
import { ref, computed } from "vue"
import { useRoute } from "vue-router"

export default {
  name: "Layout",
  components: {
    HomeFilled,
    User,
    Bell,
    Search,
    ArrowDown,
    Expand,
    Fold,
  },
  data() {
    return {
      // 搜索查询字符串
      searchQuery: "",
      // 搜索结果列表
      searchResults: [],
      // 人员列表数据

      personList: [
        {
          id: 1,
          name: "王强",
          age: 33,
          position: "架构师",
          avatar: "/src/assets/avatar1.png",
          editing: false,
        },
        {
          id: 2,
          name: "张伟",
          age: 34,
          position: "ai设计师",
          avatar: "/src/assets/avatar2.png",
          editing: false,
        },
        {
          id: 3,
          name: "王李",
          age: 35,
          position: "公司法人",
          avatar: "/src/assets/3.png",
          editing: false,
        },
        {
          id: 4,
          name: "赵高",
          age: 36,
          position: "数据分析师",
          avatar: "/src/assets/avatar4.png",
          editing: false,
        },
        {
          id: 5,
          name: "嬴政",
          age: 37,
          position: "数据分析师",
          avatar: "/src/assets/avatar5.png",
          editing: false,
        },
        {
          id: 6,
          name: "华佗",
          age: 38,
          position: "数据分析师",
          avatar: "/src/assets/avatar6.png",
          editing: false,
        },
        {
          id: 7,
          name: "刘备",
          age: 39,
          position: "后端开发工程师",
          avatar: "/src/assets/avatar7.png",
          editing: false,
        },
        {
          id: 8,
          name: "关羽",
          age: 40,
          position: "产品经理",
          avatar: "/src/assets/avatar8.png",
          editing: false,
        },
        {
          id: 9,
          name: "张飞",
          age: 20,
          position: "后端开发工程师",
          avatar: "/src/assets/avatar9.png",
          editing: false,
        },
        {
          id: 10,
          name: "赵云",
          age: 21,
          position: "后端开发工程师",
          avatar: "/src/assets/avatar10.png",
          editing: false,
        },
        {
          id: 11,
          name: "孙权",
          age: 22,
          position: "数据科学家",
          avatar: "/src/assets/avatar11.png",
          editing: false,
        },
        {
          id: 12,
          name: "曹操",
          age: 23,
          position: "UI/UX设计师",
          avatar: "/src/assets/avatar12.png",
          editing: false,
        },
        {
          id: 13,
          name: "小乔",
          age: 24,
          position: "安全工程师",
          avatar: "/src/assets/avatar13.png",
          editing: false,
        },
        {
          id: 14,
          name: "大桥",
          age: 25,
          position: "项目经理",
          avatar: "/src/assets/avatar14.png",
          editing: false,
        },
        {
          id: 15,
          name: "力扬",
          age: 26,
          position: "软件工程师",
          avatar: "/src/assets/avatar15.png",
          editing: false,
        },
      ],


      username: localStorage.getItem("username") || "",
    }
  },
  methods: {
    // 执行搜索方法
    performSearch() {
      if (this.searchQuery.trim() === "") {
        this.searchResults = [] // 如果搜索查询为空，清空搜索结果
        return
      }

      // 过滤人员列表，匹配搜索查询
      this.searchResults = this.personList.filter((person) =>
        person.name.toLowerCase().includes(this.searchQuery.toLowerCase())
      )

      console.log("搜索结果:", this.searchResults) // 打印搜索结果到控制台
    },
    // 添加新人员到人员列表
    addNewPerson(newPerson) {
      this.personList.push(newPerson)
      this.notificationsStore.addPerson(newPerson)
    },
    // 处理退出登录命令
    handleCommand(command) {
      if (command === "logout") {
        this.$message.success("退出登录成功")
        localStorage.setItem("isAuthenticated", false)
        this.$router.push("/login")
      }
    },
  },
  setup() {
    const isCollapse = ref(false)
    const route = useRoute()
    const notificationsStore = useNotificationsStore()

    // 计算当前路由名称
    const currentRoute = computed(() => {
      const routeMap = {
        "/home": "首页",
        "/person-list": "人员列表",
        "/notifications": "通知",
      }
      return routeMap[route.path] || "首页"
    })

    const toggleCollapse = () => {
      isCollapse.value = !isCollapse.value
    }

    return {
      notificationsStore,
      isCollapse,
      toggleCollapse,
      currentRoute,
    }
  },
}
</script>

<style lang="scss" scoped>
/* 全局变量定义 */
$menu-bg: #1e1e2d;
$menu-hover: #2a2a3c;
$menu-active: #2b2b40;
$menu-text: #a2a3b7;
$menu-active-text: #ffffff;
$header-bg: #ffffff;
$primary-color: #6993ff;
$border-color: #ebeef5;

/* 布局容器 */
.layout-container {
  height: 100vh;

  /* 侧边栏样式 */
  .aside {
    background-color: $menu-bg;
    transition: all 0.3s ease;
    border-right: 1px solid rgba(255, 255, 255, 0.05);

    /* Logo样式 */
    .logo {
      height: 60px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(0, 0, 0, 0.1);
      padding: 0 20px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);

      h1 {
        color: #fff;
        font-size: 18px;
        margin: 0;
        font-weight: 500;
        white-space: nowrap;
        background: linear-gradient(45deg, #6993ff, #8ab4ff);
        /* 文字显示效果 */
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        letter-spacing: 1px;
      }
    }

    /* 菜单样式 */
    .el-menu {
      border-right: none;
      background-color: transparent;

      .el-menu-item {
        height: 50px;
        line-height: 50px;
        margin: 4px 0;

        &:hover {
          background-color: $menu-hover !important;
        }

        &.is-active {
          background-color: $menu-active !important;
          border-right: 3px solid $primary-color;

          &::before {
            content: "";
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 3px;
          }
        }

        .el-icon {
          margin-right: 16px;
          font-size: 18px;
          color: $menu-text;
        }

        span {
          color: $menu-text;
          font-size: 14px;
        }

        &.is-active {
          .el-icon,
          span {
            color: $menu-active-text;
          }
        }
      }
    }
  }

  /* 头部样式 */
  .header {
    background-color: $header-bg;
    box-shadow: 0 1px 4px rgba(0, 0, 0, 0.05);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 24px;
    height: 60px;
    border-bottom: 1px solid $border-color;

    .header-left {
      display: flex;
      align-items: center;

      .fold-btn {
        font-size: 20px;
        cursor: pointer;
        padding: 8px;
        border-radius: 4px;
        color: #606266;
        transition: all 0.3s ease;
        margin-right: 16px;

        &:hover {
          background: rgba(115, 103, 240, 0.1);
          color: #55de92;
        }
      }

      /* 面包屑样式 */
      :deep(.el-breadcrumb) {
        line-height: 1;

        .el-breadcrumb__item {
          .el-breadcrumb__inner {
            color: #606266;
            font-weight: normal;

            &.is-link {
              color: #7367f0;
              font-weight: 500;

              &:hover {
                color: #938af4;
              }
            }
          }

          &:last-child {
            .el-breadcrumb__inner {
              color: #303133;
              font-weight: 500;
            }
          }
        }
      }
    }

    .user-info {
      .avatar-container {
        display: flex;
        align-items: center;
        cursor: pointer;
        padding: 0 12px;
        height: 60px;
        border-radius: 6px;
        transition: all 0.3s ease;

        &:hover {
          background: rgba(105, 147, 255, 0.05);
        }

        .avatar {
          width: 36px;
          height: 36px;
          border-radius: 8px;
          margin-right: 10px;
          border: 2px solid rgba(105, 147, 255, 0.1);
          transition: all 0.3s ease;

          &:hover {
            transform: scale(1.05);
          }
        }

        .username {
          font-size: 14px;
          color: #2c3e50;
          margin-right: 6px;
          font-weight: 500;
        }

        .el-icon {
          color: #909399;
          transition: transform 0.3s ease;
        }

        &:hover .el-icon {
          transform: rotate(180deg);
        }
      }
    }
  }

  /* 主要内容区域样式 */
  .main {
    background-color: #f6f9fc;
    padding: 24px;
    height: calc(100vh - 60px);
    overflow-y: auto;

    /* 路由切换动画 */
    .fade-enter-active,
    .fade-leave-active {
      transition: opacity 0.3s ease;
    }

    .fade-enter-from,
    .fade-leave-to {
      opacity: 0;
    }

    .fade-enter-to,
    .fade-leave-from {
      opacity: 1;
    }

    /* 滚动条样式 */
    &::-webkit-scrollbar {
      width: 6px;
    }

    &::-webkit-scrollbar-thumb {
      background: #d1d5db;
      border-radius: 3px;

      &:hover {
        background: #9ca3af;
      }
    }

    &::-webkit-scrollbar-track {
      background: #f6f9fc;
    }
  }
}

/* 下拉菜单样式覆盖 */
:deep(.el-dropdown-menu) {
  padding: 6px 0;
  border: none;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  border-radius: 8px;

  .el-dropdown-menu__item {
    padding: 8px 20px;
    font-size: 14px;

    &:hover {
      background-color: rgba(105, 147, 255, 0.05);
      color: $primary-color;
    }

    &.el-dropdown-menu__item--divided {
      border-top: 1px solid $border-color;
      margin-top: 6px;
      padding-top: 6px;
    }
  }
}

/* 移除面包屑的focus边框 */
:deep(.el-breadcrumb__inner) {
  &:focus {
    outline: none !important;
  }
  &:focus-visible {
    outline: none !important;
  }
}
</style>
