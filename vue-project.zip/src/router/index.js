// src/router/index.js
import { createRouter, createWebHistory } from 'vue-router';
import Login from '../views/login/index.vue';
import Layout from '../layout/index.vue';
import PersonList from '../views/personList/index.vue';
import PersonForm from '../components/PersonAddForm.vue'; // 引入 PersonForm 组件
import Home from '../views/home/index.vue'; // 确保导入正确的组件
import Notifications from '../views/notifications/index.vue';

const routes = [
  {
    path: '/',
    name: 'Login',
    component: Login
  },
  {
    path: '/layout',
    name: 'Layout',
    component: Layout,
    redirect: { name: '/home' }, // 重定向到 Home
    children: [
      {
        path: '/home',
        name: 'Home', // 确保名称一致
        component: Home
      },
      {
        path: '/person-list',
        name: 'PersonList',
        component: PersonList
      },
      {
        path: '/notifications',
        component: Notifications
      },
    ]
  },
  {
    path: '/Login',
    component: Login
  },
  {
    path: '/home',
    component: Home
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes
});

export default router;