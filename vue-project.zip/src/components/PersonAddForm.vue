<template>
  <!-- 人员添加表单 -->
  <el-form
    ref="formRef"
    :model="formData"
    :rules="rules"
    label-width="80px"
    class="person-form"
  >
    <!-- 姓名输入框 -->
    <el-form-item label="姓名" prop="name">
      <el-input v-model="formData.name" placeholder="请输入姓名" clearable />
    </el-form-item>

    <!-- 年龄输入框 -->
    <el-form-item label="年龄" prop="age">
      <el-input-number
        v-model="formData.age"
        :min="18"
        :max="100"
        class="w-full"
      />
    </el-form-item>

    <!-- 职位输入框 -->
    <el-form-item label="职位" prop="position">
      <el-input
        v-model="formData.position"
        placeholder="请输入职位"
        clearable
      />
    </el-form-item>

    <!-- 头像上传 -->
    <el-form-item label="头像" prop="avatar">
      <el-upload
        class="avatar-uploader"
        action="#"
        :show-file-list="false"
        :auto-upload="false"
        :on-change="handleAvatarChange"
      >
        <img v-if="formData.avatar" :src="formData.avatar" class="avatar" />
        <el-icon v-else class="avatar-uploader-icon"><Plus /></el-icon>
      </el-upload>
    </el-form-item>

    <!-- 表单底部按钮 -->
    <div class="form-footer">
      <el-button @click="handleCancel">取消</el-button>
      <el-button type="primary" @click="handleSubmit">确定</el-button>
    </div>
  </el-form>
</template>

<script>
import { ref } from "vue"
import { Plus } from "@element-plus/icons-vue"
import { ElMessage } from "element-plus"

export default {
  name: "PersonAddForm",
  components: {
    Plus,
  },
  emits: ["submit", "cancel"],
  setup(props, { emit }) {
    const formRef = ref(null)
    const formData = ref({
      name: "",
      age: 18,
      position: "",
      avatar: "",
    })

    const rules = {
      name: [
        { required: true, message: "请输入姓名", trigger: "blur" },
        { min: 2, max: 10, message: "长度在 2 到 10 个字符", trigger: "blur" },
      ],
      age: [
        { required: true, message: "请输入年龄", trigger: "blur" },
        {
          type: "number",
          min: 18,
          max: 100,
          message: "年龄必须在18到100岁之间",
          trigger: "blur",
        },
      ],
      position: [{ required: true, message: "请输入职位", trigger: "blur" }],
    }

    // 头像变更处理
    const handleAvatarChange = (file) => {
      formData.value.avatar = URL.createObjectURL(file.raw)
    }

    // 提交表单
    const handleSubmit = async () => {
      if (!formRef.value) return

      await formRef.value.validate((valid) => {
        if (valid) {
          emit("submit", { ...formData.value })
        }
      })
    }

    const handleCancel = () => {
      emit("cancel")
    }

    return {
      formRef,
      formData,
      rules,
      handleAvatarChange,
      handleSubmit,
      handleCancel,
    }
  },
}
</script>

<style lang="scss" scoped>
/* 表单容器样式 */
.person-form {
  .el-form-item {
    margin-bottom: 24px;

    &:last-child {
      margin-bottom: 0;
    }

    .el-input-number {
      width: 100%;
    }
  }

  /* 头像上传样式 */
  .avatar-uploader {
    :deep(.el-upload) {
      border: 1px dashed #d9d9d9;
      border-radius: 8px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
      transition: all 0.3s;

      &:hover {
        border-color: #7367f0;
      }
    }

    /* 上传图标样式 */
    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 120px;
      height: 120px;
      text-align: center;
      line-height: 120px;
    }

    /* 头像预览样式 */
    .avatar {
      width: 120px;
      height: 120px;
      display: block;
      object-fit: cover;
      border-radius: 8px;
    }
  }
}

/* 表单底部样式 */
.form-footer {
  display: flex;
  justify-content: flex-end;
  gap: 12px;
  margin-top: 30px;

  /* 按钮样式 */
  .el-button {
    padding: 9px 20px;
    font-size: 14px;
    border-radius: 6px;

    /* 主要按钮样式 */
    &.el-button--primary {
      background: linear-gradient(135deg, #7367f0, #9f94ff);
      border: none;

      &:hover {
        background: linear-gradient(135deg, #6355e4, #8b7ff7);
      }
    }
  }
}
</style>
