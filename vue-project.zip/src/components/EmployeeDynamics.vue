<template>
  <div class="employee-dynamics">
    <ul class="dynamics-list">
      <li v-for="(dynamic, index) in dynamics" :key="dynamic.timestamp" class="dynamic-item">
        <div class="timeline-point"></div>
        <div class="dynamic-content">
          <div class="user-info">
            <el-avatar :size="32" src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png" />
            <span class="username">{{ dynamic.name }}</span>
            <el-tag size="small" :type="getActionType(dynamic.message)" class="action-tag">
              {{ getActionLabel(dynamic.message) }}
            </el-tag>
            <el-button size="mini" type="danger" @click="deleteMessage(index)" class="delete-button" style="padding: 0; min-width: 0; background-color: white;">
              🗑️ 
            </el-button>
          </div>
          <p class="message">{{ dynamic.message }}</p>
          <div class="time-info">
            <el-icon><Timer /></el-icon>
            <span>{{ dynamic.time }}</span>
          </div>
        </div>
      </li>
    </ul>

    <div class="message-input">
      <input v-model="newMessage" placeholder="请输入您的动态..." />
      <el-button type="primary" @click="sendMessage">发布</el-button>
    </div>
  </div>
</template>

<script>
import { Timer } from "@element-plus/icons-vue";

export default {
  components: {
    Timer,
  },
  data() {
    return {
      dynamics: [], // 动态消息数组
      newMessage: '', // 新的消息内容
      updateInterval: null, // 更新消息时间的定时器
      ws: null, // WebSocket实例
    };
  },
  created() {
    this.loadDynamics(); // 初始化时加载动态信息
    this.initWebSocket(); // 初始化WebSocket连接
  },
  mounted() {
    this.updateInterval = setInterval(() => {
      this.loadDynamics(); // 定期更新动态信息
    }, 60000); // 每分钟更新一次
  },
  beforeDestroy() {
    clearInterval(this.updateInterval); // 清除定时器
    if (this.ws) {
      this.ws.close(); // 关闭WebSocket连接
    }
  },
  methods: {
    initWebSocket() {
      this.ws = new WebSocket('ws://10.40.10.38:3000'); // 替换为实际服务器地址

      this.ws.onmessage = (event) => {
        const dynamic = JSON.parse(event.data);
        // 检查消息是否已存在，存在则不添加，避免重复展示
        if (!this.dynamics.some(d => d.timestamp === dynamic.timestamp)) {
          this.dynamics.push(dynamic); 
        }
      };

      this.ws.onopen = () => {
        console.log('WebSocket connection established');
      };

      this.ws.onclose = () => {
        console.log('WebSocket connection closed');
      };
    },

    async sendMessage() {
      if (this.newMessage.trim() !== '') {
        const currentTime = new Date();
        const currentUser = localStorage.getItem("username") || "未知用户";

        const dynamic = {
          name: currentUser,
          message: this.newMessage.trim(),
          time: this.formatTime(currentTime),
          timestamp: currentTime.getTime(),
        };

        // 发送数据到后端
        await fetch('http://10.40.10.38:3000/api/dynamics', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(dynamic),
        });

        // 清空消息
        this.newMessage = '';
        
        // 通过WebSocket发送动态信息
        this.ws.send(JSON.stringify(dynamic)); // 通过WebSocket广播消息
      }
    },

    async loadDynamics() {
      // 这里不再清空现有的动态信息，而是采用合并去重的方式处理
      const response = await fetch('http://10.40.10.38:3000/api/dynamics');
      if (response.ok) {
        const fetchedDynamics = await response.json();
        // 合并去重逻辑，将获取到的数据与现有数据合并并去除重复项
        const combinedDynamics = [...this.dynamics, ...fetchedDynamics].reduce((acc, current) => {
          const isExist = acc.some(d => d.timestamp === current.timestamp);
          if (!isExist) {
            acc.push(current);
          }
          return acc;
        }, []);
        this.dynamics = combinedDynamics;

        this.updateDynamicTimes(); // 更新时间信息
      } else {
        console.error('Failed to load dynamics');
      }
    },

    deleteMessage(index) {
      const dynamicToDelete = this.dynamics[index];
      
      // 调用后端API进行删除
      fetch(`http://10.40.10.38:3000/api/dynamics/${dynamicToDelete.timestamp}`, {
        method: 'DELETE',
      })
      .then(() => {
        // 从前端数组中移除动态信息
        this.dynamics.splice(index, 1); // 从数组中删除对应的动态消息
      })
      .catch(error => {
        console.error('Error deleting dynamic:', error);
      });
    },

    updateDynamicTimes() {
      const now = new Date();
      this.dynamics.forEach(dynamic => {
        const dynamicDate = new Date(dynamic.timestamp);
        dynamic.time = this.formatTime(dynamicDate);
      });
    },

    formatTime(date) {
      const now = new Date();
      const seconds = Math.floor((now - date) / 1000); // 计算时间差（秒）

      if (seconds < 60) {
        return '刚刚';
      } else if (seconds < 3600) {
        return `${Math.floor(seconds / 60)}分钟前`;
      } else if (seconds < 86400) {
        return `${Math.floor(seconds / 3600)}小时前`;
      } else {
        return `${Math.floor(seconds / 86400)}天前`;
      }
    },

    getActionType(message) {
      if (message.includes("完成") || message.includes("解决")) return "success";
      if (message.includes("安排") || message.includes("发布")) return "warning";
      if (message.includes("参加")) return "info";
      if (message.includes("处理")) return "danger";
      return "info";
    },

    getActionLabel(message) {
      if (message.includes("完成")) return "完成";
      if (message.includes("安排")) return "安排";
      if (message.includes("解决")) return "解决";
      if (message.includes("发布")) return "发布";
      if (message.includes("参加")) return "参与";
      if (message.includes("处理")) return "处理";
      return "动态";
    },
  },
};
</script>

<style lang="scss" scoped>
/* 员工动态容器样式 */
.employee-dynamics {
  padding: 0 10px;
  height: 100%;
  display: flex;
  flex-direction: column;

  /* 动态列表样式 */
  .dynamics-list {
    list-style: none;
    padding: 0;
    margin: 0;
    position: relative;
    height: 350px;
    overflow-y: auto;

    /* 滚动条样式 */
    &::-webkit-scrollbar {
      width: 6px;
    }
    &::-webkit-scrollbar-thumb {
      background: #d1d5db;
      border-radius: 3px;
      &:hover {
        background: #9ca3af;
      }
    }
    &::-webkit-scrollbar-track {
      background: #f6f9fc;
    }

    /* 时间线样式 */
    &::before {
      content: "";
      position: absolute;
      left: 16px;
      top: 0;
      bottom: 0;
      width: 2px;
      background: #f0f2f5;
      z-index: 1;
    }

    /* 动态项目样式 */
    .dynamic-item {
      position: relative;
      padding: 12px 0 12px 48px;

      &:not(:last-child) {
        border-bottom: 1px solid #f0f2f5;
      }

      /* 时间线节点样式 */
      .timeline-point {
        position: absolute;
        left: 11px;
        top: 24px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #fff;
        border: 2px solid #7367f0;
        z-index: 2;
        transition: all 0.3s ease;
      }

      /* 悬停效果 */
      &:hover {
        .timeline-point {
          transform: scale(1.2);
          box-shadow: 0 0 0 4px rgba(115, 103, 240, 0.1);
        }
      }

      /* 动态内容样式 */
      .dynamic-content {
        /* 用户信息样式 */
        .user-info {
          display: flex;
          align-items: center;
          margin-bottom: 6px;

          .username {
            margin: 0 12px;
            font-weight: 500;
            color: #303133;
          }

          .action-tag {
            font-size: 12px;
            padding: 0 8px;
            height: 20px;
            line-height: 18px;
          }

          /* 删除按钮样式 */
          .el-button {
            margin-left: 10px;
          }
        }

        /* 消息样式 */
        .message {
          margin: 0 0 6px 0;
          color: #606266;
          font-size: 14px;
          padding-left: 40px;
        }

        /* 时间信息样式 */
        .time-info {
          padding-left: 40px;
          color: #909399;
          font-size: 12px;
          display: flex;
          align-items: center;

          .el-icon {
            margin-right: 4px;
            font-size: 14px;
          }
        }
      }
    }
  }

  /* 消息输入框样式 */
  .message-input {
    display: flex;
    gap: 10px;
    margin-top: auto; /* 确保输入框在底部 */
    padding: 10px 0;

    input {
      flex: 1; /* 输入框占满剩余空间 */
      padding: 10px;
      border: 1px solid #e0e0e0;
      border-radius: 4px;
      outline: none;

      &:focus {
        border-color: #7367f0; /* 聚焦时的边框颜色 */
      }
    }
  }
}
</style>
