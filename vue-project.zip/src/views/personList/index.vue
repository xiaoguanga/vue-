<template>
  <div class="person-list-container">
    <div class="header">
      <!-- 标题区域 -->
      <div class="title-container">
        <h2 class="title-styled">人员信息</h2>
      </div>
      <div class="button-container">
        <!-- 搜索框 -->
        <el-input
          v-model="searchQuery"
          placeholder="搜索人员姓名"
          prefix-icon="el-icon-search"
          size="small"
          class="search-input"
        ></el-input>
        <!-- 添加人员按钮 -->
        <el-button type="primary" @click="showAddDialog">添加人员</el-button>
      </div>
    </div>

    <!-- 人员列表表格 -->
    <el-table
      size="large"
      :data="filteredPersonList"
      style="width: 100%; margin-top: 20px"
    >
      <el-table-column prop="name" label="姓名" width="180">
        <template #default="scope">
          <el-input v-if="scope.row.editing" v-model="scope.row.name" />
          <span v-else>{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="age" label="年龄" width="180">
        <template #default="scope">
          <el-input v-if="scope.row.editing" v-model="scope.row.age" />
          <span v-else>{{ scope.row.age }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="position" label="职位">
        <template #default="scope">
          <el-input v-if="scope.row.editing" v-model="scope.row.position" />
          <span v-else>{{ scope.row.position }}</span>
        </template>
      </el-table-column>
      <el-table-column prop="avatar" label="头像">
        <template #default="scope">
          <el-image
            :src="scope.row.avatar"
            fit="cover"
            style="width: 50px; height: 50px; border-radius: 50%"
          />
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template #default="scope">
          <!-- 编辑/保存按钮 -->
          <el-button
            size="small"
            type="warning"
            @click="edit(scope.row)"
            v-if="!scope.row.editing"
            >编辑</el-button
          >
          <el-button size="small" type="success" @click="save(scope.row)" v-else
            >保存</el-button
          >
          <!-- 删除确认弹窗 -->
          <el-popconfirm
            title="确定要删除这条记录吗？"
            @confirm="deletePerson(scope.row)"
            confirm-button-text="确定"
            cancel-button-text="取消"
          >
            <template #reference>
              <el-button size="small" type="danger">删除</el-button>
            </template>
          </el-popconfirm>
        </template>
      </el-table-column>
    </el-table>

    <!-- 添加人员模态框 -->
    <el-dialog
      v-model="dialogVisible"
      title="添加人员"
      width="500px"
      :close-on-click-modal="false"
      destroy-on-close
      class="person-dialog"
    >
      <PersonAddForm @submit="handleSubmit" @cancel="handleCancel" />
    </el-dialog>
  </div>
</template>

<script>
import { ref, computed } from "vue"
import PersonAddForm from "../../components/PersonAddForm.vue"
import { useNotificationsStore } from "../../store/notifications"
import { ElMessage } from "element-plus"

export default {
  components: {
    PersonAddForm,
  },

  setup() {
    const notificationsStore = useNotificationsStore()
    const dialogVisible = ref(false)
    const searchQuery = ref('')

    // 计算属性：过滤后的人员列表
    const filteredPersonList = computed(() => {
      if (!searchQuery.value) {
        return notificationsStore.personList
      }
      return notificationsStore.personList.filter(person =>
        person.name.toLowerCase().includes(searchQuery.value.toLowerCase())
      )
    })

    // 显示添加对话框
    const showAddDialog = () => {
      dialogVisible.value = true
    }

    // 处理表单提交
    const handleSubmit = (formData) => {
      notificationsStore.addPerson(formData)
      ElMessage.success("添加成功")
      dialogVisible.value = false
    }

    // 处理取消操作
    const handleCancel = () => {
      dialogVisible.value = false
    }

    // 编辑人员信息
    const edit = (person) => {
      person.editing = true
    }

    // 保存编辑后的信息
    const save = (person) => {
      person.editing = false
      notificationsStore.updatePerson(person)
    }

    // 删除人员
    const deletePerson = (person) => {
      notificationsStore.deletePerson(person.id)
    }

    return {
      dialogVisible,
      searchQuery,
      filteredPersonList,
      showAddDialog,
      handleSubmit,
      handleCancel,
      edit,
      save,
      deletePerson,
    }
  },
}
</script>

<style scoped>
/* 人员列表容器样式 */
.person-list-container {
  padding: 20px;
}

/* 头部样式 */
.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

/* 标题容器样式 */
.title-container {
  margin-bottom: 24px;

  .title-styled {
    font-size: 24px;
    color: #303133;
    font-weight: 600;
    margin: 0;
  }
}

/* 按钮容器样式 */
.button-container {
  display: flex;
  align-items: center;
}

/* 搜索框样式 */
.search-input {
  width: 200px;
  margin-right: 15px;
  border-radius: 4px;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

/* 进行输入框的聚焦样式 */
.search-input .el-input__inner:focus {
  border-color: #409eff; /* Element Plus 的主色调 */
  box-shadow: 0 0 5px rgba(64, 158, 255, 0.5);
}

/* 模态框样式 */
:deep(.person-dialog) {
  .el-dialog {
    border-radius: 12px;
    overflow: hidden;

    /* 对话框头部样式 */
    .el-dialog__header {
      margin: 0;
      padding: 20px;
      border-bottom: 1px solid #f0f0f0;

      .el-dialog__title {
        font-size: 18px;
        font-weight: 600;
        color: #303133;
      }
    }

    /* 对话框内容区域样式 */
    .el-dialog__body {
      padding: 30px 20px;
    }

    /* 对话框底部样式 */
    .el-dialog__footer {
      padding: 10px 20px 20px;
      border-top: 1px solid #f0f0f0;
    }
  }
}
</style>
