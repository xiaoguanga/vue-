<template>
  <div class="login">
    <div class="title">人员管理系统</div>
    <el-tabs v-model="activeTab">
      <el-tab-pane label="登录" name="login">
        <el-form label-position="top" label-width="100px">
          <el-form-item label="用户名">
            <el-input v-model="username"></el-input>
          </el-form-item>
          <el-form-item label="密码">
            <el-input type="password" v-model="password"></el-input>
          </el-form-item>
          <el-form-item label="验证码" v-if="showCaptcha">
            <el-input v-model="captcha" placeholder="请输入验证码"></el-input>
            <span class="captcha-text">{{ generatedCaptcha }}</span>
          </el-form-item>
          <el-button
            type="primary"
            @click="login"
            style="width: 100%; margin-top: 20px"
          >登录</el-button>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="注册" name="register">
        <el-form label-position="top" label-width="100px">
          <el-form-item label="用户名">
            <el-input v-model="registerUsername"></el-input>
          </el-form-item>
          <el-form-item label="密码">
            <el-input type="password" v-model="registerPassword"></el-input>
          </el-form-item>
          <el-form-item label="确认密码">
            <el-input type="password" v-model="confirmPassword"></el-input>
          </el-form-item>
          <el-button
            type="primary"
            @click="register"
            style="width: 100%; margin-top: 20px"
          >注册</el-button>
        </el-form>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
export default {
  data() {
    return {
      activeTab: "login", // 当前激活的标签页
      username: "", // 用户名输入框的值
      password: "", // 密码输入框的值
      captcha: "", // 验证码输入框的值
      generatedCaptcha: "", // 生成的验证码
      incorrectAttempts: 0, // 错误尝试次数
      showCaptcha: false, // 是否显示验证码输入框
      registerUsername: "", // 注册用户名输入框的值
      registerPassword: "", // 注册密码输入框的值
      confirmPassword: "", // 确认密码输入框的值
    }
  },
  mounted() {
    // 检查是否有用户数据
    const existingUsers = JSON.parse(localStorage.getItem("users")) || []
    if (existingUsers.length === 0) {
      // 如果没有用户数据，提示用户注册
      this.$message.warning("请先注册一个账户")
    }
  },
  methods: {
    generateCaptcha() {
      // 生成4位随机数字验证码
      const randomNum = Math.floor(1000 + Math.random() * 9000)
      this.generatedCaptcha = randomNum.toString()
    },
    login() {
      console.log("尝试登录:", this.username, this.password)
      // 从 localStorage 中读取用户数据
      const users = JSON.parse(localStorage.getItem("users")) || []
      console.log("用户数据:", users)

      // 查找匹配的用户
      const user = users.find(
        (u) => u.username === this.username && u.password === this.password
      )
      console.log("匹配的用户:", user)

      if (user) {
        if (this.showCaptcha) {
          // 验证验证码
          if (this.captcha === this.generatedCaptcha) {
            // 验证码正确，重置错误尝试次数
            this.incorrectAttempts = 0
            this.showCaptcha = false
            // 登录成功，设置认证状态并跳转到首页
            localStorage.setItem("isAuthenticated", true)
            localStorage.setItem("username", this.username)
            this.$message.success("登录成功")
            this.$router.push("/home")
          } else {
            this.$message.error("验证码错误")
          }
        } else {
          // 登录成功，设置认证状态并跳转到首页
          localStorage.setItem("isAuthenticated", true)
          localStorage.setItem("username", this.username)
          this.$message.success("登录成功")
          this.$router.push("/home")
          this.incorrectAttempts = 0 // 重置错误尝试次数
          this.showCaptcha = false // 隐藏验证码输入框
        }
      } else {
        // 登录失败，增加错误尝试次数
        this.incorrectAttempts++
        if (this.incorrectAttempts >= 3) {
          this.showCaptcha = true
          this.generateCaptcha() // 生成新的验证码
        }
        this.$message.error("用户名或密码错误")
      }
    },
    register() {
      // 检查密码是否一致
      if (this.registerPassword !== this.confirmPassword) {
        this.$message.error("两次输入的密码不一致")
        return
      }

      // 模拟注册逻辑
      const users = JSON.parse(localStorage.getItem("users")) || []
      const existingUser = users.find(
        (u) => u.username === this.registerUsername
      )

      if (existingUser) {
        this.$message.error("用户名已存在")
        return
      }

      // 添加新用户
      users.push({
        username: this.registerUsername,
        password: this.registerPassword,
      })
      localStorage.setItem("isAuthenticated", false) // 注册后未登录
      localStorage.setItem("users", JSON.stringify(users))

      this.$message.success("注册成功")
      this.activeTab = "login" // 切换到登录标签页
    },
  },
  /* 监听标签页变化，清空表单数据 */
  watch: {
    activeTab(newVal) {
      // 清空表单数据
      if (newVal === "login") {
        this.username = ""
        this.password = ""
        this.captcha = ""
      } else if (newVal === "register") {
        this.registerUsername = ""
        this.registerPassword = ""
        this.confirmPassword = ""
      }
    },
  },
}
</script>

<style lang="scss" scoped>
/* 全局变量定义 */
$primary-color: #409eff;
$gradient-start: #aeeeee; /* 浅蓝色渐变起始色 */
$gradient-end: #50b3e0; /* 浅蓝色渐变结束色 */
$card-bg: rgba(255, 255, 255, 0.95);
$box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
// 新增花瓣颜色变量
$petal-color: rgba(255, 100, 100, 0.8);
// 新增花瓣大小变量
$petal-size: 30px;

/* 重置页面基础样式 */
body,
html {
  margin: 0;
  padding: 0;
  height: 100%;
  overflow: hidden;
}

/* 登录页面容器样式 */
.login {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background: linear-gradient(135deg, $gradient-start 0%, $gradient-end 100%);
  position: relative;
  overflow: hidden;

  /* 背景动态效果装饰 */
  &::before {
    content: "";
    position: absolute;
    width: 2000px;
    height: 2000px;
    border-radius: 50%;
    background: linear-gradient(
      45deg,
      rgba(255, 255, 255, 0.1),
      rgba(255, 255, 255, 0.05)
    );
    animation: rotate 20s linear infinite;
    top: -50%;
    left: -50%;
    z-index: 0;
  }

  /* 背景动态效果装饰 */
  &::after {
    content: "";
    position: absolute;
    width: 1500px;
    height: 1500px;
    border-radius: 50%;
    background: linear-gradient(
      -45deg,
      rgba(255, 255, 255, 0.08),
      rgba(255, 255, 255, 0.03)
    );
    animation: rotate 15s linear infinite reverse;
    bottom: -50%;
    right: -50%;
    z-index: 0;
  }

  // 添加花瓣的伪元素（这里添加多个伪元素模拟多个花瓣）
  &::before {
    content: "";
    position: absolute;
    width: $petal-size;
    height: $petal-size;
    background-color: $petal-color;
    border-radius: 50%;
    animation: floatPetal 10s linear infinite;
    top: 10%;
    left: 20%;
    z-index: 0;
  }
  &::after {
    content: "";
    position: absolute;
    width: $petal-size;
    height: $petal-size;
    background-color: $petal-color;
    border-radius: 50%;
    animation: floatPetal 12s linear infinite;
    top: 50%;
    left: 60%;
    z-index: 0;
  }
}

/* 页面标题样式 */
.title {
  font-size: 36px; /* 更新字体大小 */
  font-weight: 700; /* 加重字体 */
  color: rgba(255, 255, 255, 0.9); /* 增加透明度 */
  margin-bottom: 30px;
  text-align: center;
  position: relative;
  z-index: 1;
  text-shadow: 2px 2px 10px rgba(0, 0, 0, 0.5); /* 增加更深的阴影效果 */
  letter-spacing: 2px;
  transform: translateY(-20px);
  animation: fadeInDown 0.8s ease-out forwards;
}

/* 选项卡容器样式 */
.el-tabs {
  width: 380px;
  background-color: $card-bg;
  padding: 30px;
  border-radius: 16px;
  box-shadow: $box-shadow;
  position: relative;
  z-index: 1;
  backdrop-filter: blur(10px);
  animation: fadeIn 0.8s ease-out forwards;
}

/* 表单容器样式 */
.el-form {
  width: 100%;

  /* 表单项样式 */
  :deep(.el-form-item) {
    margin-bottom: 25px;

    /* 表单标签样式 */
    .el-form-item__label {
      padding-bottom: 8px;
      font-weight: 500;
      color: #606266;
    }

    /* 输入框样式 */
    .el-input {
      --el-input-hover-border-color: #{$primary-color};
      --el-input-focus-border-color: #{$primary-color};

      /* 输入框容器样式 */
      .el-input__wrapper {
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        transition: all 0.3s ease;
        border-radius: 8px;
        padding: 0 15px;

        /* 输入框悬停效果 */
        &:hover {
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        /* 输入框聚焦效果 */
        &.is-focus {
          box-shadow: 0 4px 12px rgba(68, 129, 235, 0.2);
        }
      }

      /* 输入框元素样式 */
      input {
        height: 42px;
        font-size: 14px;
      }
    }
  }
}

/* 按钮样式 */
.el-button {
  width: 100%;
  margin-top: 30px;
  height: 44px;
  font-size: 16px;
  font-weight: 500;
  border-radius: 8px;
  background: linear-gradient(45deg, $gradient-start, $gradient-end);
  border: none;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  /* 按钮光效装饰 */
  &::before {
    content: "";
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      120deg,
      transparent,
      rgba(255, 255, 255, 0.3),
      transparent
    );
    transition: 0.5s;
  }

  /* 按钮悬停效果 */
  &:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(68, 129, 235, 0.4);

    &::before {
      left: 100%;
    }
  }

  /* 按钮点击效果 */
  &:active {
    transform: translateY(0);
  }
}

/* 验证码文本样式 */
.captcha-text {
  display: inline-block;
  margin-left: 15px;
  font-size: 16px;
  color: #606266;
  font-weight: 600;
  letter-spacing: 2px;
  user-select: none;
  padding: 5px 10px;
  border-radius: 4px;
}

/* 旋转动画定义 */
@keyframes rotate {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
}

/* 淡入动画定义 */
@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 从上淡入动画定义 */
@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translateY(-40px);
  }
  to {
    opacity: 1;
    transform: translateY(-20px);
  }
}

// 定义花瓣飘动的动画关键帧
@keyframes floatPetal {
  0% {
    transform: translate(0, 0);
    opacity: 1;
  }
  50% {
    transform: translate(100px, 100px);
    opacity: 0.5;
  }
  100% {
    transform: translate(200px, 200px);
    opacity: 0;
  }
}

/* 响应式布局样式 */
@media screen and (max-width: 480px) {
  .el-tabs {
    width: 90%;
    max-width: 380px;
    padding: 20px;
  }

  .title {
    font-size: 28px;
  }
}
</style>
