<template>
  <div class="home-container">
    <!-- 用户信息卡片区域 -->
    <el-card class="welcome-card">
      <div class="user">
        <!-- 头像区域 -->
        <div class="avatar-wrapper">
          <img src="../../assets/p1.jpg" alt="" class="avatar" />
          <div class="status-dot"></div>
        </div>
        <!-- 用户信息区域 -->
        <div class="userinfo">
          <h2 class="name">欢迎您, {{ username }}!</h2>
          <p class="access">管理员</p>
          <!-- 登录信息区域 -->
          <div class="login-info">
            <div class="info-item">
              <el-icon><Timer /></el-icon>
              <span>上次登录时间：{{ currentTime }}</span>
            </div>
            <div class="info-item">
              <el-icon><Location /></el-icon>
              <span>上次登录地点：成都市</span>
            </div>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 数据展示区域 -->
    <el-row :gutter="20" class="data-section">
      <!-- 左侧员工收入表格 -->
      <el-col :span="14">
        <el-card class="data-card">
          <template #header>
            <div class="card-header">
              <span>员工列表</span>
            </div>
          </template>
          <!-- 员工收入表格 -->
          <el-table
            :data="tableData"
            style="width: 100%"
            :header-cell-style="{
              background: '#f8f9fc',
              color: '#606266',
            }"
            :cell-style="{
              padding: '12px 0',
            }"
          >
            <!-- 姓名列 -->
            <el-table-column prop="name" label="姓名" width="140">
              <template #default="scope">
                <div class="name-cell">
                  <el-avatar
                    :size="28"
                    src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"
                  />
                  <span>{{ scope.row.name }}</span>
                </div>
              </template>
            </el-table-column>
            <!-- 职位列 -->
            <el-table-column prop="work" label="职位" width="140">
              <template #default="scope">
                <el-tag size="small" :type="getPositionTagType(scope.row.work)">
                  {{ scope.row.work }}
                </el-tag>
              </template>
            </el-table-column>
            <!-- 本月收入列 -->
            <el-table-column prop="monthBuy" label="本月收入" width="170">
              <template #default="scope">
                <span class="income"
                  >¥ {{ formatNumber(scope.row.monthBuy) }}</span
                >
              </template>
            </el-table-column>
            <!-- 总收入列 -->
            <el-table-column prop="totalBuy" label="总收入" width="200">
              <template #default="scope">
                <span class="income"
                  >¥ {{ formatNumber(scope.row.totalBuy) }}</span
                >
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
      <!-- 右侧员工动态 -->
      <el-col :span="10">
        <el-card class="data-card">
          <template #header>
            <div class="card-header">
              <span>员工动态</span>
            </div>
          </template>
          <EmployeeDynamics />
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import EmployeeDynamics from "../../components/EmployeeDynamics.vue"
import moment from "moment"
import { Timer, Location } from "@element-plus/icons-vue"

export default {
  components: {
    EmployeeDynamics,
    Timer,
    Location,
  },
  data() {
    return {
      tableData: [
        {
          name: "name1",
          work: "董事长",
          monthBuy: 10000000,
          totalBuy: 1000000000,
        },
        {
          name: "name2",
          work: "总裁",
          monthBuy: 8000000,
          totalBuy: 800000000,
        },
        {
          name: "3",
          work: "总经理",
          monthBuy: 500000,
          totalBuy: 5000000,
        },
        {
          name: "4",
          work: "副经理",
          monthBuy: 500000,
          totalBuy: 5000000,
        },
        {
          name: "5",
          work: "项目负责人",
          monthBuy: 200000,
          totalBuy: 20000000,
        },
        {
          name: "小明",
          work: "牛马工程师",
          monthBuy: 2500,
          totalBuy: 50000,
        },
      ],
      username: localStorage.getItem("username") || "",
      currentTime: moment().format("YYYY-MM-DD"),
    }
  },
  methods: {
    // 格式化数字
    formatNumber(num) {
      return num.toLocaleString("zh-CN", {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })
    },
    // 根据职位返回不同的标签类型
    getPositionTagType(position) {
      const typeMap = {
        董事长: "danger",
        总裁: "warning",
        总经理: "success",
        副经理: "info",
        项目负责人: "primary",
        牛马工程师: "warning",
      }
      return typeMap[position] || "info"
    },
  },
}
</script>

<style lang="scss" scoped>
/* 主容器样式 */
.home-container {
  padding: 20px;
  background-color: #f6f9fc;
  min-height: calc(100vh - 120px);

  /* 欢迎卡片样式 */
  .welcome-card {
    margin-bottom: 24px;
    border-radius: 12px;
    border: none;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
    background: linear-gradient(135deg, #7367f0 0%, #9f94ff 100%);

    /* 卡片内容区域样式 */
    :deep(.el-card__body) {
      padding: 30px;
    }

    /* 用户信息区域样式 */
    .user {
      display: flex;
      align-items: center;

      /* 头像容器样式 */
      .avatar-wrapper {
        position: relative;
        margin-right: 40px;

        /* 头像图片样式 */
        .avatar {
          width: 120px;
          height: 120px;
          border-radius: 50%;
          border: 4px solid rgba(255, 255, 255, 0.2);
          transition: all 0.3s ease;

          /* 头像悬停效果 */
          &:hover {
            transform: scale(1.05);
            border-color: rgba(255, 255, 255, 0.4);
          }
        }

        /* 在线状态指示点样式 */
        .status-dot {
          position: absolute;
          bottom: 8px;
          right: 8px;
          width: 14px;
          height: 14px;
          background-color: #52c41a;
          border-radius: 50%;
          border: 2px solid #fff;
          box-shadow: 0 0 0 2px rgba(82, 196, 26, 0.2);
        }
      }

      /* 用户信息文本样式 */
      .userinfo {
        color: #fff;

        /* 用户名样式 */
        .name {
          font-size: 28px;
          font-weight: 600;
          margin: 0 0 8px 0;
          letter-spacing: 0.5px;
        }

        /* 权限信息样式 */
        .access {
          font-size: 16px;
          margin-bottom: 16px;
          opacity: 0.9;
        }

        /* 登录信息样式 */
        .login-info {
          .info-item {
            display: flex;
            align-items: center;
            margin-bottom: 8px;
            opacity: 0.8;
            font-size: 14px;

            /* 图标样式 */
            .el-icon {
              margin-right: 8px;
            }
          }
        }
      }
    }
  }

  /* 数据展示区域样式 */
  .data-section {
    .data-card {
      border-radius: 12px;
      border: none;
      box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
      height: 100%;

      /* 卡片头部样式 */
      :deep(.el-card__header) {
        padding: 16px 20px;
        border-bottom: 1px solid #f0f0f0;
      }

      /* 卡片标题区域样式 */
      .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;

        span {
          font-size: 16px;
          font-weight: 500;
          color: #303133;
        }
      }

      /* 表格样式 */
      :deep(.el-table) {
        /* 名称单元格样式 */
        .name-cell {
          display: flex;
          align-items: center;
          gap: 8px;
        }

        /* 收入数字样式 */
        .income {
          font-family: "Roboto Mono", monospace;
          color: #7367f0;
          font-weight: 500;
        }
      }
    }
  }
}
</style>
