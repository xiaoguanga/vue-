<template>
  <div class="notifications-container">
    <div class="header">
      <h2 class="title">操作日志</h2>
      <el-tag type="info" class="count-tag"
        >共 {{ notifications.length }} 条记录</el-tag
      >
    </div>

    <div class="notifications-list" v-if="notifications.length">
      <div
        v-for="notification in notifications"
        :key="notification.id"
        class="notification-item"
      >
        <div class="message">
          <!-- 图标 -->
          <el-icon :class="getIconClass(notification.message)">
            <component :is="getIcon(notification.message)" />
          </el-icon>

          <!-- 文本 -->
          <span :class="getTextClass(notification.message)">
            {{ parseMessage(notification.message) }}
          </span>
        </div>
        <div class="time">{{ notification.date }}</div>
      </div>
    </div>

    <el-empty v-else description="暂无操作记录" />
  </div>
</template>

<script>
import { useNotificationsStore } from "../../store/notifications"
import { computed } from "vue"
import { Delete, Edit, Plus } from "@element-plus/icons-vue"

export default {
  name: "Notifications",
  components: {
    Delete,
    Edit,
    Plus,
  },

  setup() {
    const notificationsStore = useNotificationsStore()
    const notifications = computed(() => notificationsStore.notifications)

    // 获取图标
    const getIcon = (message) => {
      if (message.includes("删除")) return Delete
      if (message.includes("更新")) return Edit
      if (message.includes("添加")) return Plus
      return Edit
    }

    // 获取图标类
    const getIconClass = (message) => {
      let baseClass = "status-icon "
      if (message.includes("删除")) return baseClass + "delete"
      if (message.includes("更新")) return baseClass + "update"
      if (message.includes("添加")) return baseClass + "add"
      return baseClass
    }

    // 获取文本类
    const getTextClass = (message) => {
      if (message.includes("删除")) return "text-delete"
      if (message.includes("更新")) return "text-update"
      if (message.includes("添加")) return "text-add"
      return ""
    }

    // 解析消息
    const parseMessage = (message) => {
      // 保持原始消息不变，因为已经是格式化好的
      return message
    }

    return {
      notifications,
      getIcon,
      getIconClass,
      getTextClass,
      parseMessage,
    }
  },
}
</script>
<style lang="scss" scoped>
/* 通知容器样式 */
.notifications-container {
  padding: 24px;
  height: 100%;
  background: #f8f9fc;

  /* 头部样式 */
  .header {
    display: flex;
    align-items: center;
    margin-bottom: 24px;

    /* 标题样式 */
    .title {
      margin: 0;
      font-size: 24px;
      color: #1d2129;
      font-weight: 600;
    }

    /* 数量标签样式 */
    .count-tag {
      margin-left: 12px;
      font-weight: normal;
    }
  }

  /* 通知列表样式 */
  .notifications-list {
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
    overflow: hidden;

    /* 通知项样式 */
    .notification-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 24px;
      border-bottom: 1px solid #f0f0f0;
      transition: all 0.3s ease;

      /* 最后一项去除底部边框 */
      &:last-child {
        border-bottom: none;
      }

      /* 悬停效果 */
      &:hover {
        background: #f9fafc;
      }

      /* 消息内容样式 */
      .message {
        display: flex;
        align-items: center;
        gap: 8px;
        font-size: 14px;

        /* 状态图标样式 */
        .status-icon {
          font-size: 16px;

          /* 删除状态图标 */
          &.delete {
            color: #f56c6c;
          }

          /* 更新状态图标 */
          &.update {
            color: #e6a23c;
          }

          /* 添加状态图标 */
          &.add {
            color: #67c23a;
          }
        }

        /* 删除文本样式 */
        .text-delete {
          color: #f56c6c;
        }

        /* 更新文本样式 */
        .text-update {
          color: #e6a23c;
        }

        /* 添加文本样式 */
        .text-add {
          color: #67c23a;
        }
      }

      /* 时间样式 */
      .time {
        font-size: 13px;
        color: #86909c;
        margin-left: 16px;
      }
    }
  }

  /* Element Plus 空状态样式覆盖 */
  :deep(.el-empty) {
    padding: 60px 0;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
  }
}
</style>
