const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const WebSocket = require('ws');

const app = express();
const port = 3000;

app.use(cors());
app.use(bodyParser.json());

let dynamics = []; // 数据存储

const server = app.listen(port, () => {
    console.log(`Server is running on http://10.40.10.38:${port}`);
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    console.log('Client connected');

    ws.on('message', (message) => {
        const dynamic = JSON.parse(message);
        // 先检查是否已存在，不存在再添加，避免重复存储
        if (!dynamics.some(d => d.timestamp === dynamic.timestamp)) {
            dynamics.push(dynamic); 
        }
        // 广播给所有连接的客户端
        wss.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify(dynamic));
            }
        });
    });


    ws.on('close', () => {
        console.log('Client disconnected');
    });
});

// POST请求，添加去重逻辑后再存储数据
app.post('/api/dynamics', (req, res) => {
    const dynamic = req.body;
    // 检查是否已存在相同时间戳的动态消息，不存在则添加
    if (!dynamics.some(d => d.timestamp === dynamic.timestamp)) {
        dynamics.push(dynamic);
    }
    res.status(201).json(dynamic);

    // 广播新动态给所有连接的WebSocket客户端
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(dynamic));
        }
    });
});

// GET请求，返回数据时无需特殊去重，因为后端存储时已做去重控制
app.get('/api/dynamics', (req, res) => {
    res.json(dynamics);
});

// DELETE请求
app.delete('/api/dynamics/:timestamp', (req, res) => {
    const timestamp = parseInt(req.params.timestamp);
    dynamics = dynamics.filter(dynamic => dynamic.timestamp!== timestamp);
    res.status(204).send();
});